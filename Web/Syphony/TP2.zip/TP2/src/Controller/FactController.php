<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class FactController extends AbstractController
{
    /**
     * @Route("/fact", name="app_fact")
     */
    public function index(): Response
    {
        return $this->render('fact/index.html.twig', [
            'controller_name' => 'FactController',
        ]);
    }
    /**
    * @Route("/fact/{x<\d+>?1}")
    */
    function factcontroller($x){ 
        return new Response(fact($x)); 
      }

          /**
    * @Route("/combinaison/{n<\d+>?1}/{p<\d+>?1}")
    */
    function Combinaison($n,$p){ 
        return new Response(Combinaison($p,$n)); 
      }



}

function fact($x){ 
    $f = 1; 
    for ($i = 1; $i <= $x; $i++){ 
      $f = $f * $i; 
    } 
    return $f; 
}

function Combinaison($x,$y){ 
    
    return fact($x)/(fact($y)*fact($x -$y)); 
}

