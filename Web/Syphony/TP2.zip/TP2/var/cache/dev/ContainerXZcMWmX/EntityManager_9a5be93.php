<?php

namespace ContainerXZcMWmX;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder98efa = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializere28ce = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties817c3 = [
        
    ];

    public function getConnection()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getConnection', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getMetadataFactory', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getExpressionBuilder', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'beginTransaction', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->beginTransaction();
    }

    public function getCache()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getCache', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getCache();
    }

    public function transactional($func)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'transactional', array('func' => $func), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'wrapInTransaction', array('func' => $func), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'commit', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->commit();
    }

    public function rollback()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'rollback', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getClassMetadata', array('className' => $className), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'createQuery', array('dql' => $dql), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'createNamedQuery', array('name' => $name), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'createQueryBuilder', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'flush', array('entity' => $entity), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'clear', array('entityName' => $entityName), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->clear($entityName);
    }

    public function close()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'close', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->close();
    }

    public function persist($entity)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'persist', array('entity' => $entity), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'remove', array('entity' => $entity), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'refresh', array('entity' => $entity), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'detach', array('entity' => $entity), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'merge', array('entity' => $entity), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getRepository', array('entityName' => $entityName), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'contains', array('entity' => $entity), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getEventManager', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getConfiguration', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'isOpen', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getUnitOfWork', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getProxyFactory', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'initializeObject', array('obj' => $obj), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'getFilters', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'isFiltersStateClean', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'hasFilters', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return $this->valueHolder98efa->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializere28ce = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder98efa) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder98efa = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder98efa->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, '__get', ['name' => $name], $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        if (isset(self::$publicProperties817c3[$name])) {
            return $this->valueHolder98efa->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder98efa;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder98efa;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, '__set', array('name' => $name, 'value' => $value), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder98efa;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder98efa;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, '__isset', array('name' => $name), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder98efa;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder98efa;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, '__unset', array('name' => $name), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder98efa;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder98efa;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, '__clone', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        $this->valueHolder98efa = clone $this->valueHolder98efa;
    }

    public function __sleep()
    {
        $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, '__sleep', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;

        return array('valueHolder98efa');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializere28ce = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializere28ce;
    }

    public function initializeProxy() : bool
    {
        return $this->initializere28ce && ($this->initializere28ce->__invoke($valueHolder98efa, $this, 'initializeProxy', array(), $this->initializere28ce) || 1) && $this->valueHolder98efa = $valueHolder98efa;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder98efa;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder98efa;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
